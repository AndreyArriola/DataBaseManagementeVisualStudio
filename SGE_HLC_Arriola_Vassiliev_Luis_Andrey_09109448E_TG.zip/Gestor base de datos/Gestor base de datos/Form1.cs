﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Gestor_base_de_datos
{
    public partial class Form1 : Form
    {
        String cadenaconexion = "Data Source=SERVERFOC\\NAVDEMO;Initial Catalog=Northwind;Integrated Security=True";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'northwindDataSet.Customers' Puede moverla o quitarla según sea necesario.
            this.customersTableAdapter.Fill(this.northwindDataSet.Customers);

        }

        private void btAlta_Click(object sender, EventArgs e)
        {
            try
            {
                using(SqlConnection con = new SqlConnection(cadenaconexion))
                {
                    string sql = "insert into Customers (CustomerID, CompanyName) values (@id, @nombre)";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Connection.Open();

                    cmd.Parameters.AddWithValue("@id", txtID.Text);
                    cmd.Parameters.AddWithValue("@nombre", txtCompany.Text);

                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                    MessageBox.Show("Se a dado de alta correctamente");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
}

        private void btList_Click(object sender, EventArgs e)
        {
            string sql = "select * from Customers;";

            SqlDataAdapter da = new SqlDataAdapter(sql, cadenaconexion);
            DataTable table = new DataTable();
            da.Fill(table);

            dgView.DataSource = table;

            dgView.AutoResizeColumns();
        }

        private void btBaja_Click(object sender, EventArgs e)
        {
            Object idcostumer = dgView.CurrentRow.Cells[0].Value;

            try
            {
                using (SqlConnection con = new SqlConnection(cadenaconexion))
                {
                    string sql = "delete from Customers where CustomerID = @id";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Connection.Open();

                    cmd.Parameters.AddWithValue("@id", idcostumer);
                 

                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();

                    MessageBox.Show("Se a borrado correctamente");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}